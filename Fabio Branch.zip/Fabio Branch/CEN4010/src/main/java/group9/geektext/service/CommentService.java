package group9.geektext.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import group9.geektext.entity.Comment;
import group9.geektext.entity.User;
import group9.geektext.entity.Book;
import group9.geektext.repository.CommentRepository;
import group9.geektext.repository.UserRepository;
import group9.geektext.repository.BookRepository;

@Service
@Transactional
public class CommentService {

    private final CommentRepository commentRepository;
    private final UserRepository userRepository;
    private final BookRepository bookRepository;

    public CommentService(CommentRepository commentRepository, UserRepository userRepository, BookRepository bookRepository) {
        this.commentRepository = commentRepository;
        this.userRepository = userRepository;
        this.bookRepository = bookRepository;
    }

    // Save a new comment
    public Comment createComment(Comment comment) {
        // Retrieve the related user and book objects
        User user = userRepository.findById(comment.getUser().getId()).orElseThrow(() -> new RuntimeException("User not found"));
        Book book = bookRepository.findById(comment.getBook().getId()).orElseThrow(() -> new RuntimeException("Book not found"));

        comment.setUser(user);
        comment.setBook(book);
        return commentRepository.save(comment);
    }

    // Get all comments for a specific book
    public List<Comment> getCommentsByBook(Long bookId) {
        return commentRepository.findByBook_Id(bookId);
    }

    // Get all comments by a specific user
    public List<Comment> getCommentsByUser(Long userId) {
        return commentRepository.findByBook_Id(userId);
    }

    // Update an existing comment
    public Comment updateComment(Comment comment) {
        Optional<Comment> existingComment = commentRepository.findById(comment.getId());
        if (existingComment.isPresent()) {
            Comment updatedComment = existingComment.get();
            updatedComment.setComment(comment.getComment());
            updatedComment.setBook(comment.getBook()); // If you want to update the book too
            updatedComment.setUser(comment.getUser()); // If you want to update the user too
            return commentRepository.save(updatedComment);
        }
        throw new RuntimeException("Comment not found"); // Handle this case as you see fit
    }

    // Delete a comment
    public void deleteComment(Long commentId) {
        commentRepository.deleteById(commentId);
    }
}
