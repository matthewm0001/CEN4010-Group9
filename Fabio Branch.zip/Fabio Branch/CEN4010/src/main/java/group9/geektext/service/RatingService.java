package group9.geektext.service;

import org.springframework.stereotype.Service;
import group9.geektext.entity.Book;
import group9.geektext.entity.Rating;
import group9.geektext.repository.BookRepository;
import group9.geektext.repository.RatingRepository;

import java.util.List;

@Service
public class RatingService {

    private final RatingRepository ratingRepository;
    private final BookRepository bookRepository;

    // Constructor injection for both repositories
    public RatingService(RatingRepository ratingRepository, BookRepository bookRepository) {
        this.ratingRepository = ratingRepository;
        this.bookRepository = bookRepository;
    }

    // Get all ratings for a book
    public List<Rating> getRatingsByBook(Long bookId) {
        return ratingRepository.findByBook_Id(bookId);
    }

    // Get all ratings by a user
    public List<Rating> getRatingsByUser(Long userId) {
        return ratingRepository.findByUser_Id(userId);
    }

    // Create a new rating and associate it with a book
    public Rating createRating(Rating rating, Long bookId) {
        // Find the book by bookId, throw an exception if not found
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new RuntimeException("Book not found"));

        // Set the book to the rating
        rating.setBook(book);

        // Save the rating
        return ratingRepository.save(rating);
    }

    // Update a rating
    public Rating updateRating(Rating updatedRating) {
        return ratingRepository.save(updatedRating);
    }

    // Delete a rating
    public void deleteRating(Long ratingId) {
        ratingRepository.deleteById(ratingId);
    }
}
