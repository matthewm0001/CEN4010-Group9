create definer = root@localhost view topsellers as
select `geek_text`.`books`.`id`          AS `id`,
       `geek_text`.`books`.`title`       AS `title`,
       `geek_text`.`books`.`copies_sold` AS `copies_sold`
from `geek_text`.`books`
order by `geek_text`.`books`.`copies_sold` desc
limit 10;

